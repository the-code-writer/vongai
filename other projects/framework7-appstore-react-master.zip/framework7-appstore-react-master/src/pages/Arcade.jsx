import React from 'react';

import {
  Block,
} from 'framework7-react';

import AppstorePage from '../components/AppstorePage';

const Arcade = () => {
  return (
    <AppstorePage title="Arcade">
      <Block>Work in progress</Block>
    </AppstorePage>
  );
};

export default Arcade;
